package com.tencent.liteav.demo.player.expand.model.entity;

/**
 * Created by vinsonswang on 2018/3/28.
 */

public class VideoInfo {
    public String fileId;
    public String name;
    public String coverUrl;

    public int size;
    public int duration;

    public long createTime;
}
